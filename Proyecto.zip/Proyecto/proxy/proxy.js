const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors()); // Habilita CORS para todas las rutas
app.use(express.json()); // Para parsear JSON

// Ruta que actuará como proxy para EmailJS
app.post('/send-email', async (req, res) => {
  try {
    const response = await axios.post('https://api.emailjs.com/api/v1.0/email/send', req.body, {
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'http://localhost:5500' // Asegúrate de que coincida con tu origen
      }
    });
    res.status(200).json(response.data);
  } catch (error) {
    console.error('Error en el proxy:', error);
    res.status(500).json({ error: 'Error al enviar el correo' });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Proxy corriendo en http://localhost:${PORT}`);
});