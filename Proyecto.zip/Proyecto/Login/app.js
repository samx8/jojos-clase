document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const roleCards = document.querySelectorAll('.role-card');
    const forms = document.querySelectorAll('.login-form');
    const adminForm = document.getElementById('admin-form');
    
    // Estado inicial - mostrar solo los roles
    forms.forEach(form => {
        form.classList.remove('active');
    });
    
    // Manejar clic en las tarjetas de rol
    roleCards.forEach(card => {
        card.addEventListener('click', function() {
            const role = this.dataset.role;
            
            // Ocultar todos los formularios primero
            forms.forEach(form => {
                if (form.classList.contains('active')) {
                    form.style.animation = 'slideUp 0.5s forwards';
                    setTimeout(() => {
                        form.classList.remove('active');
                    }, 500);
                }
            });
            
            // Mostrar el formulario correspondiente después de ocultar los demás
            setTimeout(() => {
                const formToShow = document.getElementById(`${role}-form`);
                formToShow.classList.add('active');
                formToShow.style.animation = 'slideDown 0.5s forwards';
                
                // Resaltar la tarjeta seleccionada
                roleCards.forEach(c => {
                    c.style.opacity = '1';
                    c.style.transform = 'translateY(0)';
                });
                this.style.opacity = '0.7';
                this.style.transform = 'translateY(-5px)';
            }, 500);
        });
    });
    
    // Manejar envío del formulario de admin
    adminForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validación básica
        const username = this.querySelector('input[type="text"]').value.trim();
        const password = this.querySelector('input[type="password"]').value.trim();
        
        if (!username || !password) {
            alert('Por favor complete todos los campos');
            return;
        }
        
        // Redirección al dashboard de admin
        window.location.href = '../admin/Dashboard/Dashboard.html';
    });
    
    // Manejar envío de otros formularios
    document.getElementById('medic-form').addEventListener('submit', function(e) {
        e.preventDefault();
        // Lógica para médico
        alert('Redirección a dashboard de médico');
    });
    
    document.getElementById('patient-form').addEventListener('submit', function(e) {
        e.preventDefault();
        // Lógica para paciente
        alert('Redirección a dashboard de paciente');
    });
});