// Script para manejar la navegación entre páginas
document.addEventListener('DOMContentLoaded', function() {
    // Enlaces de navegación
    const dashboardLink = document.getElementById('dashboard-link');
    const agendaLink = document.getElementById('agenda-link');
    const hceLink = document.getElementById('hce-link');
    const reportesLink = document.getElementById('reportes-link');
    const configuracionLink = document.getElementById('configuracion-link');
    const rolesLink = document.querySelector('.menu-item[id="roles-link"]'); // Para gestión de roles si existe

    // Función para navegar a una ruta
    function navigateTo(path) {
        window.location.href = path;
    }

    // Asignar eventos de clic a los enlaces
    if (dashboardLink) {
        dashboardLink.addEventListener('click', function() {
            navigateTo('../Dashboard/Dashboard.html');
        });
    }

    if (agendaLink) {
        agendaLink.addEventListener('click', function() {
            navigateTo('../Agenda_Global/Agenda.html');
        });
    }

    if (hceLink) {
        hceLink.addEventListener('click', function() {
            navigateTo('../HCE/hce.html');
        });
    }

    if (reportesLink) {
        reportesLink.addEventListener('click', function() {
            navigateTo('../Reportes/reportes.html');
        });
    }

    if (configuracionLink) {
        configuracionLink.addEventListener('click', function() {
            navigateTo('../Configuracion/configuracion.html');
        });
    }

    if (rolesLink) {
        rolesLink.addEventListener('click', function() {
            navigateTo('../Gestion_de_roles/Roles.html');
        });
    }
    
    // Agregar botón de cerrar sesión al menú lateral
    const menuList = document.querySelector('.menu');
    if (menuList) {
        // Verificar si ya existe un botón de cerrar sesión en el menú
        let logoutMenuItem = menuList.querySelector('.menu-item.logout-item');
        
        if (!logoutMenuItem) {
            // Crear el elemento de menú para cerrar sesión
            logoutMenuItem = document.createElement('li');
            logoutMenuItem.className = 'menu-item logout-item';
            logoutMenuItem.innerHTML = `
                <span class="material-symbols-outlined menu-icon">logout</span>
                Cerrar sesión
            `;
            
            // Agregar el elemento al final del menú
            menuList.appendChild(logoutMenuItem);
            
            // Agregar evento al elemento de cerrar sesión
            logoutMenuItem.addEventListener('click', function() {
                // Redirigir al login
                window.location.href = '../../Login/index.html';
            });
        }
    }
    
    // Eliminar el código anterior que agregaba el botón a la barra superior
    // (ya no es necesario porque ahora está en el menú lateral)
});