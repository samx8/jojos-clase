document.addEventListener('DOMContentLoaded', function() {
  // Referencias a elementos del DOM
  const hceTable = document.querySelector('.hce-table tbody');
  const hceModal = document.getElementById('hce-modal');
  const closeModal = document.querySelector('.close-modal');
  const cancelBtn = document.querySelector('.cancel-btn');
  const saveBtn = document.querySelector('.save-btn');
  const nuevaHceBtn = document.getElementById('nueva-hce');
  const exportarBtn = document.getElementById('exportar-hce');
  const searchInput = document.querySelector('.search-input');
  const filterBtns = document.querySelectorAll('.filter-btn');
  
  // Referencias a elementos de filtro adicionales
  const fechaInicio = document.getElementById('fecha-inicio');
  const fechaFin = document.getElementById('fecha-fin');
  const medicoFilter = document.getElementById('medico-filter');
  
  // Campos del formulario
  const modalPaciente = document.getElementById('modal-paciente-input'); // Cambiado a input para editar
  const hceFecha = document.getElementById('hce-fecha');
  const hceMedico = document.getElementById('hce-medico'); // Restauramos la referencia al médico
  const hceEditor = document.getElementById('hce-editor'); // Añadimos referencia al último editor
  const hceDiagnostico = document.getElementById('hce-diagnostico');
  const hceMedicamentos = document.getElementById('hce-medicamentos');
  const hceAlergias = document.getElementById('hce-alergias');
  const hceAntecedentes = document.getElementById('hce-antecedentes');
  
  // Variable para almacenar la fila actual que se está editando
  let currentRow = null;
  let isNewRecord = false;
  
  // Abrir modal al hacer clic en una fila
  hceTable.addEventListener('click', function(e) {
    const row = e.target.closest('tr');
    if (row) {
      openModal(row);
    }
  });
  
  // Cerrar modal
  closeModal.addEventListener('click', closeHceModal);
  cancelBtn.addEventListener('click', closeHceModal);
  
  // Guardar cambios
  saveBtn.addEventListener('click', saveChanges);
  
  // Crear nueva HCE
  nuevaHceBtn.addEventListener('click', createNewHce);
  
  // Función para abrir el modal con los datos de la fila seleccionada
  function openModal(row) {
    isNewRecord = false;
    currentRow = row;
    
    // Obtener datos de la fila
    const id = row.dataset.id;
    const nombre = row.cells[1].textContent;
    const fecha = row.dataset.fecha;
    // Obtener médico y editor desde dataset en lugar de las celdas
    const medico = row.dataset.medico || '';
    const editor = row.dataset.editor || medico;
    const diagnostico = row.dataset.diagnostico || '';
    
    // Llenar el modal con los datos
    modalPaciente.value = nombre; // Ahora es un input, usamos value
    hceFecha.value = fecha;
    hceMedico.value = medico;
    hceEditor.value = editor;
    hceDiagnostico.value = diagnostico;
    
    // Limpiar otros campos si no tienen datos
    hceMedicamentos.value = row.dataset.medicamentos || '';
    hceAlergias.value = row.dataset.alergias || '';
    hceAntecedentes.value = row.dataset.antecedentes || '';
    
    // Mostrar el modal
    hceModal.style.display = 'block';
  }
  
  // Función para cerrar el modal
  function closeHceModal() {
    hceModal.style.display = 'none';
    currentRow = null;
  }
  
  // Función para guardar los cambios
  function saveChanges() {
    if (!currentRow && !isNewRecord) return;
    
    const paciente = modalPaciente.value.trim();
    const fecha = hceFecha.value;
    const medico = hceMedico.value.trim();
    const editor = hceEditor.value.trim();
    const diagnostico = hceDiagnostico.value.trim();
    const medicamentos = hceMedicamentos.value.trim();
    const alergias = hceAlergias.value.trim();
    const antecedentes = hceAntecedentes.value.trim();
    
    // Verificar si todos los campos requeridos están llenos
    if (!paciente || !fecha || !medico || !editor) {
      alert('Por favor, complete todos los campos obligatorios: Paciente, Fecha, Médico y Último Editor');
      return;
    }
    
    // Verificar si los campos de información clínica están llenos
    const allFieldsFilled = diagnostico && medicamentos && alergias && antecedentes;
    
    // Determinar el estado basado en si todos los campos están llenos
    const estado = allFieldsFilled ? 'firmado' : 'nuevo';
    
    if (isNewRecord) {
      // Crear una nueva fila para la tabla
      const newRow = document.createElement('tr');
      const newId = 'P-' + Math.floor(1000 + Math.random() * 9000);
      
      // Formatear la fecha para mostrar (DD/Mes HH:MM)
      const selectedDate = new Date(fecha);
      const hours = selectedDate.getHours();
      const minutes = selectedDate.getMinutes() < 10 ? '0' + selectedDate.getMinutes() : selectedDate.getMinutes();
      const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      const displayDate = selectedDate.getDate() + '/' + months[selectedDate.getMonth()] + ' ' + hours + ':' + minutes;
      
      // Configurar atributos de datos
      newRow.dataset.id = newId;
      newRow.dataset.fecha = fecha;
      newRow.dataset.medico = medico;
      newRow.dataset.editor = editor;
      newRow.dataset.diagnostico = diagnostico;
      newRow.dataset.medicamentos = medicamentos;
      newRow.dataset.alergias = alergias;
      newRow.dataset.antecedentes = antecedentes;
      
      // Crear el contenido HTML de la fila con botón de borrar
      newRow.innerHTML = `
        <td>#${newId}</td>
        <td>${paciente}</td>
        <td>${displayDate}</td>
        <td><span class="status-badge ${estado}">${estado === 'firmado' ? 'Firmada' : 'Nueva'}</span></td>
        <td class="actions-cell">
          <button class="delete-btn" title="Eliminar">
            <span class="material-symbols-outlined">delete</span>
          </button>
        </td>
      `;
      
      // Agregar la nueva fila a la tabla
      hceTable.prepend(newRow);
      
      // Agregar evento al botón de borrar
      const deleteBtn = newRow.querySelector('.delete-btn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', function(e) {
          e.stopPropagation(); // Evitar que se abra el modal
          borrarHCE(newRow);
        });
      }
    } else {
      // Actualizar la fila existente
      currentRow.dataset.fecha = fecha;
      currentRow.dataset.medico = medico;
      currentRow.dataset.editor = editor;
      currentRow.dataset.diagnostico = diagnostico;
      currentRow.dataset.medicamentos = medicamentos;
      currentRow.dataset.alergias = alergias;
      currentRow.dataset.antecedentes = antecedentes;
      
      // Formatear la fecha para mostrar (DD/Mes HH:MM)
      const selectedDate = new Date(fecha);
      const hours = selectedDate.getHours();
      const minutes = selectedDate.getMinutes() < 10 ? '0' + selectedDate.getMinutes() : selectedDate.getMinutes();
      const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      const displayDate = selectedDate.getDate() + '/' + months[selectedDate.getMonth()] + ' ' + hours + ':' + minutes;
      
      // Actualizar las celdas visibles
      currentRow.cells[1].textContent = paciente;
      currentRow.cells[2].textContent = displayDate;
      currentRow.cells[3].innerHTML = `<span class="status-badge ${estado}">${estado === 'firmado' ? 'Firmada' : 'Nueva'}</span>`;
      
      // Asegurarse de que la celda de acciones existe
      if (!currentRow.querySelector('.actions-cell')) {
        const actionsCell = document.createElement('td');
        actionsCell.className = 'actions-cell';
        actionsCell.innerHTML = `
          <button class="delete-btn" title="Eliminar">
            <span class="material-symbols-outlined">delete</span>
          </button>
        `;
        currentRow.appendChild(actionsCell);
        
        // Agregar evento al botón de borrar
        const deleteBtn = currentRow.querySelector('.delete-btn');
        if (deleteBtn) {
          deleteBtn.addEventListener('click', function(e) {
            e.stopPropagation(); // Evitar que se abra el modal
            borrarHCE(currentRow);
          });
        }
      }
    }
    
    // Cerrar el modal
    closeHceModal();
  }
  
  // Función para crear una nueva HCE
  function createNewHce() {
    isNewRecord = true;
    currentRow = null;
    
    // Limpiar el formulario
    modalPaciente.value = ''; // Ahora es un input, usamos value
    
    // Establecer la fecha y hora actual
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    
    hceFecha.value = `${year}-${month}-${day}T${hours}:${minutes}`;
    
    // Seleccionar el primer médico por defecto (o dejarlo vacío)
    hceMedico.value = ''; // Dejamos que el usuario seleccione
    hceEditor.value = ''; // También dejamos que el usuario seleccione
    
    hceDiagnostico.value = '';
    hceMedicamentos.value = '';
    hceAlergias.value = '';
    hceAntecedentes.value = '';
    
    // Mostrar el modal
    hceModal.style.display = 'block';
  }
  
  // Función para verificar el estado de las HCE existentes en la tabla
  function actualizarEstadoHCE() {
    const rows = hceTable.querySelectorAll('tr');
    
    rows.forEach(row => {
      // Verificar si todos los campos requeridos tienen datos
      const diagnostico = row.dataset.diagnostico || '';
      const medicamentos = row.dataset.medicamentos || '';
      const alergias = row.dataset.alergias || '';
      const antecedentes = row.dataset.antecedentes || '';
      
      // Determinar el estado basado en si todos los campos están llenos
      const allFieldsFilled = diagnostico && medicamentos && alergias && antecedentes;
      const estado = allFieldsFilled ? 'firmado' : 'nuevo';
      
      // Actualizar la celda de estado
      row.cells[4].innerHTML = `<span class="status-badge ${estado}">${estado === 'firmado' ? 'Firmada' : 'Nueva'}</span>`;
    });
  }
  
  // Llamar a la función al cargar la página
  actualizarEstadoHCE();
  
  // Filtros de búsqueda
  // No redeclaramos searchInput ni filterBtns aquí
  
  // Eventos para los filtros
  searchInput.addEventListener('input', filterTable);
  fechaInicio.addEventListener('change', filterTable);
  fechaFin.addEventListener('change', filterTable);
  medicoFilter.addEventListener('change', filterTable);
  
  filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      filterBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      filterTable();
    });
  });
  
  // Función mejorada para filtrar la tabla
  function filterTable() {
    const searchTerm = searchInput.value.toLowerCase();
    const startDate = fechaInicio.value ? new Date(fechaInicio.value) : null;
    const endDate = fechaFin.value ? new Date(fechaFin.value) : null;
    const selectedMedico = medicoFilter.value.toLowerCase();
    const activeFilter = document.querySelector('.filter-btn.active').dataset.status;
    
    const rows = hceTable.querySelectorAll('tr');
    
    rows.forEach(row => {
      // Obtener datos de la fila
      const id = row.cells[0].textContent.toLowerCase();
      const nombre = row.cells[1].textContent.toLowerCase();
      const fechaTexto = row.cells[2].textContent; // Formato: DD/Mes HH:MM
      const estado = row.cells[3].textContent.toLowerCase();
      const medico = row.dataset.medico ? row.dataset.medico.toLowerCase() : '';
      
      // Convertir la fecha de la fila a un objeto Date para comparar
      let rowDate = null;
      if (fechaTexto) {
        // Parsear la fecha en formato DD/Mes HH:MM
        const parts = fechaTexto.split(' ');
        if (parts.length >= 2) {
          const dateParts = parts[0].split('/');
          const day = parseInt(dateParts[0]);
          const monthText = dateParts[1];
          const months = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
          const month = months.findIndex(m => monthText.toLowerCase().startsWith(m));
          
          if (month !== -1) {
            const timeParts = parts[1].split(':');
            const hours = parseInt(timeParts[0]);
            const minutes = parseInt(timeParts[1]);
            
            // Crear objeto Date (usamos el año actual)
            rowDate = new Date();
            rowDate.setMonth(month);
            rowDate.setDate(day);
            rowDate.setHours(hours);
            rowDate.setMinutes(minutes);
          }
        }
      }
      
      // Aplicar filtros
      const matchesSearch = id.includes(searchTerm) || 
                           nombre.includes(searchTerm);
      
      const matchesDateRange = (!startDate || !rowDate || rowDate >= startDate) && 
                              (!endDate || !rowDate || rowDate <= endDate);
      
      const matchesMedico = !selectedMedico || medico.includes(selectedMedico);
      
      const matchesStatus = activeFilter === 'todos' || 
                           (activeFilter === 'nuevo' && estado.includes('nueva')) || 
                           (activeFilter === 'firmado' && estado.includes('firmada'));
      
      // Mostrar u ocultar la fila según los filtros
      row.style.display = matchesSearch && matchesDateRange && matchesMedico && matchesStatus ? '' : 'none';
    });
  }
  
  // Función para cargar médicos en el filtro - Ya no es necesaria porque tenemos opciones fijas
  // Comentamos o eliminamos esta función
  /*
  function cargarMedicosFiltro() {
    const medicos = new Set();
    const rows = hceTable.querySelectorAll('tr');
    
    // Recopilar todos los médicos únicos de las filas
    rows.forEach(row => {
      const medico = row.dataset.medico;
      if (medico) {
        medicos.add(medico);
      }
    });
    
    // Limpiar opciones actuales (excepto la primera)
    while (medicoFilter.options.length > 1) {
      medicoFilter.remove(1);
    }
    
    // Agregar opciones para cada médico
    medicos.forEach(medico => {
      const option = document.createElement('option');
      option.value = medico;
      option.textContent = medico;
      medicoFilter.appendChild(option);
    });
  }
  */
  
  // Ya no necesitamos llamar a esta función
  // cargarMedicosFiltro();
  
  // Ya no necesitamos actualizar la lista de médicos
  /*
  function actualizarMedicosFiltro() {
    cargarMedicosFiltro();
  }
  */
  
  // Modificar las funciones saveChanges para actualizar los médicos
  // Ya no necesitamos esta parte
  /*
  const originalSaveChanges = saveChanges;
  saveChanges = function() {
    originalSaveChanges.apply(this, arguments);
    actualizarMedicosFiltro();
  };
  */
  
  // Función para borrar una HCE
  function borrarHCE(row) {
    if (confirm('¿Está seguro de que desea eliminar esta Historia Clínica? Esta acción no se puede deshacer.')) {
      row.remove();
      actualizarMedicosFiltro(); // Actualizar la lista de médicos en el filtro
    }
  }
  
  // Agregar botones de borrar a las filas existentes
  function agregarBotonesBorrar() {
    const rows = hceTable.querySelectorAll('tr');
    
    rows.forEach(row => {
      // Verificar si ya tiene botón de borrar
      if (!row.querySelector('.delete-btn')) {
        // Crear celda de acciones
        const actionsCell = document.createElement('td');
        actionsCell.className = 'actions-cell';
        actionsCell.innerHTML = `
          <button class="delete-btn" title="Eliminar">
            <span class="material-symbols-outlined">delete</span>
          </button>
        `;
        row.appendChild(actionsCell);
        
        // Agregar evento al botón de borrar
        const deleteBtn = row.querySelector('.delete-btn');
        if (deleteBtn) {
          deleteBtn.addEventListener('click', function(e) {
            e.stopPropagation(); // Evitar que se abra el modal
            borrarHCE(row);
          });
        }
      }
    });
  }
  
  // Llamar a la función para agregar botones de borrar cuando se carga la página
  agregarBotonesBorrar();
  
  // Cerrar el modal
  closeHceModal();
});