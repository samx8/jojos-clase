// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
  // Referencias a elementos del DOM
  const filterButtons = document.querySelectorAll('.agenda-filter-btn');
  const citasBody = document.getElementById('citas-body');
  const fechaActualElement = document.getElementById('fecha-actual');
  const totalCitasElement = document.getElementById('total-citas');
  const totalUrgenciasElement = document.getElementById('total-urgencias');
  const totalCanceladasElement = document.getElementById('total-canceladas');
  
  // Referencias para el modal de citas
  const appointmentModal = document.getElementById('appointment-modal');
  const modalTitle = document.getElementById('modal-title');
  const appointmentForm = document.getElementById('appointment-form');
  const patientNameInput = document.getElementById('patient-name');
  const appointmentDateInput = document.getElementById('appointment-date');
  const appointmentTimeInput = document.getElementById('appointment-time');
  const doctorNameSelect = document.getElementById('doctor-name');
  const isUrgentCheckbox = document.getElementById('is-urgent');
  const appointmentIdInput = document.getElementById('appointment-id');
  const closeModalBtn = document.querySelector('.close-modal');
  const cancelBtn = document.getElementById('cancel-btn');
  const saveBtn = document.getElementById('save-btn');
  
  // Formatear y mostrar la fecha actual
  const hoy = new Date();
  const opciones = { day: 'numeric', month: 'long', year: 'numeric' };
  fechaActualElement.textContent = hoy.toLocaleDateString('es-ES', opciones);
  
  // Función para filtrar citas
  function filtrarCitas(filtro) {
    const filas = citasBody.querySelectorAll('tr');
    
    filas.forEach(fila => {
      const fecha = fila.getAttribute('data-fecha');
      const esUrgente = fila.getAttribute('data-urgente') === 'true';
      
      switch(filtro) {
        case 'hoy':
          // Mostrar todas las citas de hoy (ya están filtradas en el HTML)
          fila.style.display = '';
          break;
        case 'semana':
          // Simulación: mostrar todas las citas (en un caso real, filtrarías por fecha)
          fila.style.display = '';
          break;
        case 'mes':
          // Simulación: mostrar todas las citas (en un caso real, filtrarías por fecha)
          fila.style.display = '';
          break;
        case 'urgencias':
          // Mostrar solo urgencias
          fila.style.display = esUrgente ? '' : 'none';
          break;
      }
    });
    
    // Actualizar contadores según el filtro aplicado
    actualizarContadores();
  }
  
  // Función para actualizar contadores
  function actualizarContadores() {
    const filasVisibles = Array.from(citasBody.querySelectorAll('tr')).filter(
      fila => fila.style.display !== 'none'
    );
    
    const urgencias = filasVisibles.filter(
      fila => fila.getAttribute('data-urgente') === 'true'
    );
    
    // En un caso real, tendrías un atributo para citas canceladas
    // Aquí simulamos que hay una cita cancelada
    
    totalCitasElement.textContent = filasVisibles.length;
    totalUrgenciasElement.textContent = urgencias.length;
    // Mantenemos el valor fijo para este ejemplo
    totalCanceladasElement.textContent = '1';
  }
  
  // Agregar event listeners a los botones de filtro
  filterButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Quitar clase active de todos los botones
      filterButtons.forEach(btn => btn.classList.remove('active'));
      
      // Agregar clase active al botón clickeado
      this.classList.add('active');
      
      // Filtrar citas según el botón
      const filtro = this.getAttribute('data-filter');
      filtrarCitas(filtro);
    });
  });
  
  // Inicializar con el filtro "hoy" (que ya está activo en el HTML)
  filtrarCitas('hoy');
  
  // Event listener para el botón de agendar cita
  const scheduleBtn = document.querySelector('.schedule-btn');
  scheduleBtn.addEventListener('click', function() {
    openAppointmentModal();
  });
  
  // Función para abrir el modal de citas
  function openAppointmentModal(appointmentId = null) {
    // Limpiar el formulario
    appointmentForm.reset();
    appointmentIdInput.value = '';
    
    if (appointmentId) {
      // Modo edición
      modalTitle.textContent = 'Editar Cita';
      
      // Buscar la cita en la tabla
      const appointmentRow = document.querySelector(`tr[data-id="${appointmentId}"]`);
      if (appointmentRow) {
        const patientName = appointmentRow.cells[2].textContent;
        const dateTime = appointmentRow.getAttribute('data-fecha-hora').split(' ');
        const doctor = appointmentRow.cells[1].textContent;
        const isUrgent = appointmentRow.getAttribute('data-urgente') === 'true';
        
        // Llenar el formulario con los datos de la cita
        patientNameInput.value = patientName;
        appointmentDateInput.value = dateTime[0]; // Fecha
        appointmentTimeInput.value = dateTime[1]; // Hora
        doctorNameSelect.value = doctor;
        isUrgentCheckbox.checked = isUrgent;
        appointmentIdInput.value = appointmentId;
      }
    } else {
      // Modo creación
      modalTitle.textContent = 'Agendar Nueva Cita';
      
      // Establecer fecha actual como valor predeterminado
      const today = new Date();
      const formattedDate = today.toISOString().split('T')[0];
      appointmentDateInput.value = formattedDate;
    }
    
    // Mostrar el modal
    appointmentModal.style.display = 'block';
  }
  
  // Función para cerrar el modal
  function closeAppointmentModal() {
    appointmentModal.style.display = 'none';
  }
  
  // Event listeners para cerrar el modal
  closeModalBtn.addEventListener('click', closeAppointmentModal);
  cancelBtn.addEventListener('click', closeAppointmentModal);
  window.addEventListener('click', function(event) {
    if (event.target === appointmentModal) {
      closeAppointmentModal();
    }
  });
  
  // Event listener para guardar la cita
  saveBtn.addEventListener('click', function() {
    // Validar el formulario
    if (!appointmentForm.checkValidity()) {
      alert('Por favor complete todos los campos requeridos');
      return;
    }
    
    // Obtener los valores del formulario
    const patientName = patientNameInput.value;
    const appointmentDate = appointmentDateInput.value;
    const appointmentTime = appointmentTimeInput.value;
    const doctorName = doctorNameSelect.value;
    const specialty = document.getElementById('specialty').value;
    const isUrgent = isUrgentCheckbox.checked;
    const appointmentId = appointmentIdInput.value || Date.now().toString();
    
    if (appointmentIdInput.value) {
      // Actualizar cita existente
      updateAppointment(appointmentId, patientName, appointmentDate, appointmentTime, doctorName, specialty, isUrgent);
    } else {
      // Crear nueva cita
      createAppointment(appointmentId, patientName, appointmentDate, appointmentTime, doctorName, specialty, isUrgent);
    }
    
    // Cerrar el modal
    closeAppointmentModal();
    
    // Actualizar contadores
    actualizarContadores();
  });
  
  // Función para crear una nueva cita
  function createAppointment(id, patientName, date, time, doctor, specialty, isUrgent) {
    // Crear nueva fila en la tabla
    const newRow = document.createElement('tr');
    newRow.setAttribute('data-id', id);
    newRow.setAttribute('data-fecha', date);
    newRow.setAttribute('data-fecha-hora', `${date} ${time}`);
    newRow.setAttribute('data-urgente', isUrgent);
    
    // Formatear fecha para mostrar
    const dateObj = new Date(date);
    const formattedDate = `${dateObj.getDate()}/${dateObj.getMonth() + 1}/${dateObj.getFullYear()}`;
    
    // Crear contenido de la fila con la estructura correcta
    newRow.innerHTML = `
      <td>${formattedDate}</td>
      <td>${time}</td>
      <td>${patientName}</td>
      <td>${doctor}</td>
      <td>${specialty}</td>
      <td>
        <button class="action-btn edit-btn" data-id="${id}">
          <span class="material-symbols-outlined">edit</span>
        </button>
        <button class="action-btn delete-btn" data-id="${id}">
          <span class="material-symbols-outlined">delete</span>
        </button>
      </td>
    `;
    
    // Agregar clase de urgencia si es necesario
    if (isUrgent) {
      newRow.classList.add('urgent-row');
    }
    
    // Agregar la fila a la tabla
    citasBody.appendChild(newRow);
    
    // Agregar event listeners a los botones de acción
    addActionButtonListeners(newRow);
    
    // Mostrar mensaje de éxito
    showNotification('Cita agendada correctamente', 'check_circle');
  }
  
  // Función para actualizar una cita existente
  function updateAppointment(id, patientName, date, time, doctor, specialty, isUrgent) {
    // Buscar la fila de la cita
    const row = document.querySelector(`tr[data-id="${id}"]`);
    if (!row) return;
    
    // Actualizar atributos de la fila
    row.setAttribute('data-fecha', date);
    row.setAttribute('data-fecha-hora', `${date} ${time}`);
    row.setAttribute('data-urgente', isUrgent);
    
    // Formatear fecha para mostrar
    const dateObj = new Date(date);
    const formattedDate = `${dateObj.getDate()}/${dateObj.getMonth() + 1}/${dateObj.getFullYear()}`;
    
    // Actualizar contenido de la fila
    row.cells[0].textContent = formattedDate;
    row.cells[1].textContent = time;
    row.cells[2].textContent = patientName;
    row.cells[3].textContent = doctor;
    row.cells[4].textContent = specialty;
    
    // Actualizar clase de urgencia
    if (isUrgent) {
      row.classList.add('urgent-row');
    } else {
      row.classList.remove('urgent-row');
    }
    
    // Mostrar mensaje de éxito
    showNotification('Cita actualizada correctamente', 'check_circle');
  }
  
  // Función para eliminar una cita
  function deleteAppointment(id) {
    // Buscar la fila de la cita
    const row = document.querySelector(`tr[data-id="${id}"]`);
    if (!row) return;
    
    // Confirmar eliminación
    if (confirm('¿Está seguro que desea eliminar esta cita?')) {
      // Eliminar la fila
      row.remove();
      
      // Actualizar contadores
      actualizarContadores();
      
      // Mostrar mensaje de éxito
      showNotification('Cita eliminada correctamente', 'check_circle');
    }
  }
  
  // Función para agregar event listeners a los botones de acción
  function addActionButtonListeners(row) {
    // Botón de editar
    const editBtn = row.querySelector('.edit-btn');
    if (editBtn) {
      editBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        const id = this.getAttribute('data-id');
        openAppointmentModal(id);
      });
    }
    
    // Botón de eliminar
    const deleteBtn = row.querySelector('.delete-btn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        const id = this.getAttribute('data-id');
        deleteAppointment(id);
      });
    }
  }
  
  // Agregar event listeners a los botones de acción existentes
  document.querySelectorAll('.edit-btn, .delete-btn').forEach(button => {
    button.addEventListener('click', function(e) {
      e.stopPropagation();
      const id = this.getAttribute('data-id');
      
      if (this.classList.contains('edit-btn')) {
        openAppointmentModal(id);
      } else if (this.classList.contains('delete-btn')) {
        deleteAppointment(id);
      }
    });
  });
  
  // Función para mostrar notificaciones
  function showNotification(message, icon) {
    // Crear elemento de notificación si no existe
    let notification = document.querySelector('.notification');
    if (!notification) {
      notification = document.createElement('div');
      notification.className = 'notification';
      document.body.appendChild(notification);
    }
    
    // Actualizar contenido
    notification.innerHTML = `
      <span class="material-symbols-outlined">${icon}</span>
      <span>${message}</span>
    `;
    
    // Mostrar notificación
    notification.classList.add('show');
    
    // Ocultar después de 3 segundos
    setTimeout(() => {
      notification.classList.remove('show');
    }, 3000);
  }
  
  // Event listeners para los elementos del menú
  document.getElementById('dashboard-link').addEventListener('click', function() {
    window.location.href = '../Dashboard/Dashboard.html';
  });
  
  // Eliminamos la referencia al gestor de roles (roles-link)
  
  document.getElementById('hce-link').addEventListener('click', function() {
    window.location.href = '../HCE/hce.html';
  });
  
  document.getElementById('reportes-link').addEventListener('click', function() {
    window.location.href = '../Reportes/reportes.html';
  });
  
  document.getElementById('configuracion-link').addEventListener('click', function() {
    window.location.href = '../Configuracion/configuracion.html';
  });
  
  // Agregar funcionalidad para el botón de cerrar sesión
  // Primero verificamos si el botón ya existe, si no, lo creamos
  let logoutBtn = document.querySelector('.logout-btn');
  
  if (!logoutBtn) {
    // Crear el botón de cerrar sesión
    logoutBtn = document.createElement('button');
    logoutBtn.className = 'icon-btn logout-btn';
    logoutBtn.innerHTML = '<span class="material-symbols-outlined">logout</span>';
    
    // Agregar el botón al contenedor de acciones de usuario
    const userActions = document.querySelector('.user-actions');
    if (userActions) {
      userActions.appendChild(logoutBtn);
    }
  }
  
  // Agregar evento al botón de cerrar sesión
  logoutBtn.addEventListener('click', function() {
    // Redirigir al login
    window.location.href = '../../Login/index.html';
  });
});
