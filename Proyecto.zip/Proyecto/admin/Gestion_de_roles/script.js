document.addEventListener('DOMContentLoaded', function() {
  const tableBody = document.querySelector('.roles-table tbody');
  const searchInput = document.querySelector('.search-input');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const rows = Array.from(tableBody.querySelectorAll('tr'));
  const menuItems = document.querySelectorAll('.menu-item');
  
  let currentFilter = 'Todos';
  let currentSearch = '';

  // Función para aplicar filtros
  function applyFilters() {
    rows.forEach(row => {
      const name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
      const role = row.querySelector('td:nth-child(4)').textContent;
      const matchesSearch = name.includes(currentSearch.toLowerCase());
      const matchesFilter = currentFilter === 'Todos' || role === currentFilter;
      row.style.display = (matchesSearch && matchesFilter) ? '' : 'none';
    });
  }

  // Evento para el buscador
  searchInput.addEventListener('input', function() {
    currentSearch = this.value.trim();
    applyFilters();
  });

  // Eventos para los filtros de roles
  filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      filterBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      currentFilter = this.textContent;
      applyFilters();
    });
  });

  // Eliminar usuario
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const row = this.closest('tr');
      const userName = row.querySelector('td:nth-child(2)').textContent;
      
      if(confirm(`¿Estás seguro de eliminar a ${userName}?`)) {
        row.remove();
        showNotification('Usuario eliminado correctamente', 'check_circle');
      }
    });
  });

  // Redirecciones del menú
  document.getElementById('dashboard-link').addEventListener('click', function() {
    window.location.href = '../Dashboard/Dashboard.html';
  });

  document.getElementById('agenda-link').addEventListener('click', function() {
    window.location.href = '../Agenda_Global/Agenda.html';
  });

  document.getElementById('hce-link').addEventListener('click', function() {
    window.location.href = '../HCE/hce.html';
  });

  document.getElementById('reportes-link').addEventListener('click', function() {
    window.location.href = '../Reportes/Reportes.html';
  });

  document.getElementById('configuracion-link').addEventListener('click', function() {
    window.location.href = '../Configuracion/configuracion.html';
  });

  // Agregar nuevo usuario desde localStorage
  const newUserData = localStorage.getItem('newUser');
  if (newUserData) {
    const newUser = JSON.parse(newUserData);
    addUserToTable(newUser);
    showNotification('Nuevo usuario agregado exitosamente', 'check_circle');
    localStorage.removeItem('newUser');
  }

  // Función para agregar usuario a la tabla
  function addUserToTable(user) {
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
      <td>${user.id}</td>
      <td>${user.nombre}</td>
      <td>${user.email}</td>
      <td>${user.role}</td>
      <td class="actions-cell">
        <button class="action-btn delete-btn">
          <span class="material-symbols-outlined action-icon">delete</span>
          <span>Eliminar</span>
        </button>
      </td>
    `;
    
    tableBody.insertBefore(newRow, tableBody.firstChild);
    
    newRow.querySelector('.delete-btn').addEventListener('click', function() {
      const row = this.closest('tr');
      const userName = row.querySelector('td:nth-child(2)').textContent;
      if(confirm(`¿Estás seguro de eliminar a ${userName}?`)) {
        row.remove();
        showNotification('Usuario eliminado correctamente', 'check_circle');
      }
    });
  }

  // Función para mostrar notificaciones
  function showNotification(message, icon, isError = false) {
    let notification = document.querySelector('.notification');
    if (!notification) {
      notification = document.createElement('div');
      notification.className = 'notification';
      notification.innerHTML = `
        <span class="material-symbols-outlined notification-icon">${icon}</span>
        <span class="notification-text">${message}</span>
      `;
      document.body.appendChild(notification);
    }
    notification.classList.add('show');
    setTimeout(() => notification.classList.remove('show'), 3000);
  }
});